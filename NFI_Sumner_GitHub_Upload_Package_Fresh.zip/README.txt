NFI Sumner Market Intelligence Dashboard - GitHub Upload Package

Upload instructions:
1. Unzip this folder.
2. In the GitHub repository, upload BOTH:
   - index.html
   - the entire assets folder
3. Do not open or upload the image files individually.
4. GitHub Pages should serve the dashboard from index.html.

Notes:
- The dashboard images are externalized into the assets folder so index.html stays small enough for GitHub web upload.
- Keep the assets folder in the same directory as index.html.
